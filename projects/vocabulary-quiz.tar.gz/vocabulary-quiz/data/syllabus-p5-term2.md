# 英文生字測驗網站 - 小五下學期

## 考試範圍資料

### Unit 2 - 家居 (Things in the home)
**Productive Vocabulary (要識串字):**
apartment, flat, appliance, furniture, shelf, spacious, durable, cosy, efficient, electricity, renovate, run errands, do the laundry, go grocery shopping, do chores

### Unit 3 - 運動比賽 (Competitions and sports)
**Productive Vocabulary (要識串字):**
challenge, competition, instruction, athlete, participate, compete, encourage, announce, important, famous, effort, opportunity, suddenly, probably, almost, keen on

**Receptive Vocabulary (只須理解):**
engineer, referee, national, opponent, disappointed, award ceremony, delightful, impressive, exhausted, tournament

### Unit 4 - 外出用餐 (Dining out)
**Productive Vocabulary (要識串字):**
review, affordable, expensive, budget-friendly, juicy, creamy, crunchy, bland, delicious, greasy, excellent, awful, disappointing, relaxing, crowded, attentive, recommend, celebrate, prepare, order, waiter, waitress, restaurant, reservation, ambience, vibe, flavour, queue, menu, service, portion, decor, bill, beverage, dessert, cuisine, quality

**Receptive Vocabulary (只須理解):**
appetite, buffet, cutlery, appetiser, main course, aroma, service charge, well-seasoned, vegetarian, overpriced

### 文法題目類型
1. 時態填充 (Present/Past/Future)
2. 冠詞選擇 (a/an/the)
3. 關係代詞 (who/which/where/that/whose)
